#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import division

import re
import sys
import os
import numpy as np

numbins=10

correct=[]
insertion=[]
substitution=[]
totalwords=0

for line in sys.stdin:
	if re.match(r'^<', line): continue
	words=line.split(":")
	for word in words:
		values=word.split(",")
		error=values[0]
		try:
			posterior=float(values[4])
		except:
			continue	
		totalwords+=1
		if error=='C': correct.append(posterior)
		elif error=='I': insertion.append(posterior)
		elif error=='S': substitution.append(posterior)

binbounds=np.arange(0, 1.0001, 1/numbins)
chist, edges=np.histogram(correct, bins=binbounds)
ihist, edges=np.histogram(insertion, bins=binbounds)
shist, edges=np.histogram(substitution, bins=binbounds)

print "Confidence      C      I      S"
for i in range(len(chist)):
	total=sum([chist[i], ihist[i], shist[i]])
	if (total):
		print "%4.2f - %4.2f : %5.2f  %5.2f  %5.2f  (%5.2f)" % (binbounds[i], binbounds[i+1], (chist[i]/total)*100, (ihist[i]/total)*100, (shist[i]/total)*100, (total/totalwords)*100)
	