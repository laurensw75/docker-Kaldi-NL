#!/usr/bin/perl

open(IN, $ARGV[0]);
while(<IN>) {
    chop;
    @parts=split;
    $seg2file{$parts[0]}=$parts[1];
    $seg2offset{$parts[0]}=$parts[2];
}

while(<STDIN>) {
    chop;
    @parts=split;
    ($parts[0], $temp)=$parts[0]=~/(.*)-(\d+$)/;    
    $parts[2]+=$seg2offset{$parts[0]};
    $parts[0]=$seg2file{$parts[0]};
    $parts[0].="-".$temp;
    print join(" ", @parts)."\n";
}